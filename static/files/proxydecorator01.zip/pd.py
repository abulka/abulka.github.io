USE_RM = 1

if USE_RM:
    from RM import RM1
    RM = RM1()
    RM.ER("xy", "onetoone", "directional")

    class _Component(object):
        def _setThing(self, thing):         RM.R(self, thing, "xy")
        def _getThing(self):         return RM.P(self, "xy")
        def _getBack(self):          return RM.B(self, "xy")
        thing = property(_getThing, _setThing)
        back = property(_getBack)
else:
    class _Component(object):
        def __init__(self):
            self.thing = None
            self.back = None

class Component(_Component):
    def Do(self):                       # virtual
        raise 'Do not implemented'

class Thing(Component):
    def Do(self):
        return 'hi'

class Decorator(Component):
    pass

class Decorator1(Decorator):
    def Do(self):
        return '** ' + self.thing.Do() + ' **'

class Proxy(Component):
    def __init__(self):
        Component.__init__(self)
        self.thing = Thing()

    def Do(self):
        assert self.thing, 'Oops, have lost the real thing object'
        return self.thing.Do()

    def AddDecorator(self, d):
        self.InsertDecorator(d)  # TODO make this append to the list of decorators.

    def InsertDecorator(self, d):
        """
        Inserts the decorator first in the list of decorators.
        """
        d.thing = self.thing     # make decorater point to the thing you were pointing to
        self.thing = d           # point to the decorator

        if not USE_RM:
            d.back = self
            d.thing.back = d

    def RemoveDecorator(self, d):
        """
        Find the thing_A pointing to the dying decorator and
        point it at the thing the dying decorator was pointing to.
        """
        assert d.back
        d.back.thing = d.thing

        if not USE_RM:
            d.thing.back = d.back   # update back pointer!!



import unittest


class TestCase01(unittest.TestCase):

    def setUp(self):
        self.proxything = Proxy()
        self.d1 = Decorator1()

    def checkNoDecoration(self):
        self.proxything = Proxy()
        res = self.proxything.Do()
        #print res
        assert res == 'hi'

    def checkOneDecoration(self):
        self.proxything.AddDecorator(self.d1)
        res = self.proxything.Do()
        #print res
        assert res == '** hi **'

    def checkOneDecorationThenRemove(self):
        self.proxything.AddDecorator(self.d1)
        res = self.proxything.Do()
        assert res == '** hi **'

        self.proxything.RemoveDecorator(self.d1)
        res = self.proxything.Do()
        #print res
        assert res == 'hi'

class TestCase02(unittest.TestCase):

    def setUp(self):
        self.proxything = Proxy()
        self.d1 = Decorator1()
        self.d2 = Decorator1()

        self.proxything.AddDecorator(self.d1)
        self.proxything.AddDecorator(self.d2)

    def checkTwoDecorations(self):
        res = self.proxything.Do()
        assert res == '** ** hi ** **'

    def checkTwoDecorations_RemoveFirst(self):
        self.proxything.RemoveDecorator(self.d1)
        res = self.proxything.Do()
        #print res
        assert res == '** hi **'

    def checkTwoDecorations_RemoveSecond(self):
        self.proxything.RemoveDecorator(self.d2)
        res = self.proxything.Do()
        #print res
        assert res == '** hi **'

    def checkTwoDecorations_RemoveBoth_12(self):
        self.proxything.RemoveDecorator(self.d1)
        self.proxything.RemoveDecorator(self.d2)
        res = self.proxything.Do()
        #print res
        assert res == 'hi'

    def checkTwoDecorations_RemoveBoth_21(self):
        self.proxything.RemoveDecorator(self.d2)
        self.proxything.RemoveDecorator(self.d1)
        res = self.proxything.Do()
        #print res
        assert res == 'hi'



def suite():
    suite1 = unittest.makeSuite(TestCase01, 'check')
    suite2 = unittest.makeSuite(TestCase02, 'check')
    alltests = unittest.TestSuite((suite1,suite2))
    #alltests = unittest.TestSuite((suite1,))
    #alltests = unittest.TestSuite((suite2,))
    return alltests

def main():
    """ Run all the suites.  To run via a gui, then
            python unittestgui.py NestedDictionaryTest.suite
        Note that I run with VERBOSITY on HIGH  :-) just like in the old days
        with pyUnit for python 2.0
        Simply call
          runner = unittest.TextTestRunner(descriptions=0, verbosity=2)
        The default arguments are descriptions=1, verbosity=1
    """
    runner = unittest.TextTestRunner(descriptions = 0, verbosity = 2) # default is descriptions=1, verbosity=1
    #runner = unittest.TextTestRunner(descriptions=0, verbosity=1) # default is descriptions=1, verbosity=1
    runner.run(suite())

if __name__ == '__main__':
    main()


