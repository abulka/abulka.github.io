/*
 * JavaPureMVCMinimal01App.java
 */

package javapuremvcminimal01;

import org.jdesktop.application.Application;
import org.jdesktop.application.SingleFrameApplication;

import org.andy.AppFacade;

/**
 * The main class of the application.
 */
public class JavaPureMVCMinimal01App extends SingleFrameApplication {
    public JavaPureMVCMinimal01Form myForm;  // ANDY

    /**
     * At startup create and show the main frame of the application.
     */
    @Override protected void startup() {
        myForm = new JavaPureMVCMinimal01Form(this);
        AppFacade mvcfacade = AppFacade.getInst();
        mvcfacade.startup(this);
        show(myForm);
    }

    /**
     * This method is to initialize the specified window by injecting resources.
     * Windows shown in our application come fully initialized from the GUI
     * builder, so this additional configuration is not needed.
     */
    @Override protected void configureWindow(java.awt.Window root) {
    }

    /**
     * A convenient static getter for the application instance.
     * @return the instance of JavaPureMVCMinimal01App
     */
    public static JavaPureMVCMinimal01App getApplication() {
        return Application.getInstance(JavaPureMVCMinimal01App.class);
    }

    /**
     * Main method launching the application.
     */
    public static void main(String[] args) {
        launch(JavaPureMVCMinimal01App.class, args);
    }
}
