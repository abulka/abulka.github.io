package org.andy;

import org.puremvc.java.patterns.mediator.Mediator;
import org.puremvc.java.interfaces.INotification;
import javapuremvcminimal01.JavaPureMVCMinimal01Form;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyFormMediator extends Mediator implements ActionListener {

    public static final String NAME = "MyFormMediator";

	public MyFormMediator(JavaPureMVCMinimal01Form viewComponent)
	{
		super(NAME, null);

        setViewComponent(viewComponent);
        viewComponent.inputFieldTxt.addActionListener(this);
	}

    public void actionPerformed(ActionEvent evt) {
        JavaPureMVCMinimal01Form form = (JavaPureMVCMinimal01Form) viewComponent;

        this.sendNotification(AppFacade.DATA_SUBMITTED, viewComponent, form.inputFieldTxt.getText());
    }

    @Override
	public String[] listNotificationInterests()
	{
		return new String[] {AppFacade.DATA_CHANGED};
	}

    @Override
	public void handleNotification(INotification notification)
	{    
    	if(notification.getName().equals(AppFacade.DATA_CHANGED))
		{
            System.out.println("handleNotification (mediator) " + notification.getType());
            String mydata = (String) notification.getType();
            JavaPureMVCMinimal01Form form = (JavaPureMVCMinimal01Form) viewComponent;
            form.inputFieldTxt.setText(mydata);
		}
	}

}
