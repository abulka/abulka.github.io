package org.andy;

import org.puremvc.java.patterns.facade.Facade;
import javapuremvcminimal01.JavaPureMVCMinimal01App;

public class AppFacade extends Facade {

	public static final String STARTUP = "STARTUP";
	public static final String DATA_SUBMITTED = "DATA_SUBMITTED";
	public static final String DATA_CHANGED = "DATA_CHANGED";

	private static AppFacade instance = null;

	public static AppFacade getInst()
	{
		if (instance == null) {
			instance = new AppFacade();
		}
		return (AppFacade) instance;
	}

	@Override
    protected void initializeController()
	{
		super.initializeController();

		registerCommand(STARTUP, StartupCommand.class);
		registerCommand(DATA_SUBMITTED, DataSubmittedCommand.class);
	}

	public void startup(JavaPureMVCMinimal01App app)
	{
        this.sendNotification(STARTUP, app, null);
	}
}
