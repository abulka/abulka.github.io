package org.andy;

import org.puremvc.java.patterns.proxy.Proxy;

public class DataModelProxy extends Proxy {

    public static final String NAME = "DataModelProxy";

    private Data realdata;

    public DataModelProxy()
    {
        super(NAME, null);
        this.realdata = new Data();
        this.sendNotification(AppFacade.DATA_CHANGED, null, this.realdata.data);
    }

    public void setData(String data) {
        this.realdata.data = data;
        System.out.println("setData (model) " + data);
        this.sendNotification(AppFacade.DATA_CHANGED, null, this.realdata.data);
    }
    
}
