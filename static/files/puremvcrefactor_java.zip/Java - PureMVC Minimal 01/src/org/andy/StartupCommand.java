package org.andy;

import org.puremvc.java.interfaces.ICommand;
import org.puremvc.java.interfaces.INotification;
import org.puremvc.java.patterns.command.SimpleCommand;

import javapuremvcminimal01.JavaPureMVCMinimal01App;

public class StartupCommand extends SimpleCommand implements ICommand {

    public void execute(INotification notification)
    {
        System.out.println("startup execute (command) " + notification.getBody());

        JavaPureMVCMinimal01App app = (JavaPureMVCMinimal01App) notification.getBody();
        facade.registerMediator(new MyFormMediator(app.myForm));
        facade.registerProxy(new DataModelProxy());
    }
}
