package org.andy;

import org.puremvc.java.interfaces.ICommand;
import org.puremvc.java.interfaces.INotification;
import org.puremvc.java.patterns.command.SimpleCommand;

public class DataSubmittedCommand extends SimpleCommand implements ICommand {

    public void execute(INotification notification)
    {
        String mydata = (String) notification.getType();
        DataModelProxy datamodelProxy = (DataModelProxy) facade.retrieveProxy(DataModelProxy.NAME);
        datamodelProxy.setData(mydata.toUpperCase());
    }
}
