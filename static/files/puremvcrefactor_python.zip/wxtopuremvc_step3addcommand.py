import wx

import puremvc.interfaces
import puremvc.patterns.mediator
import puremvc.patterns.command  #ADD

class MyForm(wx.Panel):

    def __init__(self, parent):
        wx.Panel.__init__(self,parent,id=3)
        self.inputFieldTxt = wx.TextCtrl(self, -1, size=(170,-1), pos=(5, 10), style=wx.TE_PROCESS_ENTER)

class MyFormMediator(puremvc.patterns.mediator.Mediator, puremvc.interfaces.IMediator):
    NAME = 'MyFormMediator'

    def __init__(self, viewComponent):
        super(MyFormMediator, self).__init__(MyFormMediator.NAME, viewComponent)

        self.viewComponent.Bind(wx.EVT_TEXT_ENTER, self.onSubmit, self.viewComponent.inputFieldTxt)

    def listNotificationInterests(self):
        return []

    def handleNotification(self, notification):
        pass

    def onSubmit(self, evt):
        mydata = self.viewComponent.inputFieldTxt.GetValue()
        print "got (mediator)", mydata
        #self.viewComponent.inputFieldTxt.SetValue(mydata.upper())
        self.sendNotification(AppFacade.DATA_SUBMITTED, mydata, self.viewComponent)  #ADD
        
class DataSubmittedCommand(puremvc.patterns.command.SimpleCommand, puremvc.interfaces.ICommand):  #ADD CLASS
    def execute(self, notification):
        print "execute (command)", notification.getBody()
        mydata = notification.getBody()
        viewComponent = notification.getType()
        viewComponent.inputFieldTxt.SetValue(mydata.upper())
        
        
class AppFacade(puremvc.patterns.facade.Facade):  #ADD CLASS

    DATA_SUBMITTED = "DATA_SUBMITTED"

    @staticmethod
    def getInstance():
        return AppFacade()

    def initializeController(self):
        super(AppFacade, self).initializeController()

        super(AppFacade, self).registerCommand(AppFacade.DATA_SUBMITTED, DataSubmittedCommand)
        
        
class AppFrame(wx.Frame):
    myForm = None
    mvcfacade = None  #ADD
    
    def __init__(self):
        wx.Frame.__init__(self,parent=None, id=-1, title="Refactoring to PureMVC",size=(200,100))
        self.myForm = MyForm(self)

        #self.mvcfacade = puremvc.patterns.facade.Facade.getInstance()
        self.mvcfacade = AppFacade.getInstance()  #ADD
        self.mvcfacade.registerMediator(MyFormMediator(self.myForm ))
        

class WxApp(wx.App):
    appFrame = None

    def OnInit(self):
        self.appFrame = AppFrame()
        self.appFrame.Show()
        return True

if __name__ == '__main__':
    wxApp = WxApp(redirect=False)
    wxApp.MainLoop()

